/* index.html — hero CTA + recent attempts (only if logged in) */
document.addEventListener("DOMContentLoaded", async () => {
  const cta = document.getElementById("hero-cta");
  if (App.isLoggedIn()) {
    if (cta) cta.textContent = "Go to Dashboard";
    if (cta) cta.href = "dashboard.html";
    loadRecent();
  }

  const passBtn = document.getElementById("pass-unlock-btn");
  if (passBtn) {
    passBtn.addEventListener("click", () => {
      if (App.isLoggedIn()) App.toast("The Test Khajana Pass covers every class and chapter — enjoy! 🎉");
      else window.location.href = "register.html";
    });
  }
});

async function loadRecent() {
  const box = document.getElementById("home-recent");
  const user = App.user();
  if (!box || !user) return;
  try {
    const history = await Api.getHistory(user.user_id || user.id);
    if (!history.length) {
      box.innerHTML = `<div class="empty-state card">No tests yet — start with any chapter!</div>`;
      return;
    }
    box.innerHTML = history.slice(0, 3).map(h => `
      <a class="card row-card" href="result.html?attemptId=${h.attempt_id}">
        <div class="row-main">
          <h3>${App.escapeHtml(h.chapter_name)}</h3>
          <p class="row-sub">${App.escapeHtml(h.subject_name)} · ${App.formatDate(h.submitted_at || h.started_at)}</p>
        </div>
        <div class="row-right">
          <span class="pill ${h.score >= 60 ? "pill-green" : "pill-red"}">${Math.round(h.score)}%</span>
        </div>
      </a>`).join("");
  } catch (err) {
    box.innerHTML = `<div class="empty-state card">${App.escapeHtml(err.message)}</div>`;
  }
}
