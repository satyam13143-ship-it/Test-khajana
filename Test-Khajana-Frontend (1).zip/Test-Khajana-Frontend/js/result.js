/* result.html — score summary + answer review with explanations */
document.addEventListener("DOMContentLoaded", async () => {
  if (!App.requireAuth()) return;

  const attemptId = App.qs("attemptId");
  if (!attemptId) { window.location.replace("history.html"); return; }

  const $ = (id) => document.getElementById(id);

  try {
    const r = await Api.getResult(attemptId);
    const pct = Math.round(r.score);
    const skipped = r.total_questions - (r.correct_answers + r.wrong_answers);

    $("result-container").hidden = false;
    $("result-loading").hidden = true;

    const ring = $("score-ring");
    ring.style.setProperty("--pct", pct);
    ring.style.background =
      `radial-gradient(closest-side, #fff 79%, transparent 80% 100%), conic-gradient(${pct >= 60 ? "var(--success)" : "var(--danger)"} ${pct}%, #e2e8f0 0)`;
    $("score-pct").textContent = pct + "%";
    $("result-title").textContent = pct >= 80 ? "Outstanding! 🏆" : pct >= 60 ? "Well done! 👍" : pct >= 40 ? "Keep practising! 💪" : "Don't give up — review and retry!";
    $("result-sub").textContent = `${r.chapter_name} · ${r.subject_name} · ${r.class_display_name}`;
    $("r-correct").textContent = r.correct_answers;
    $("r-wrong").textContent = r.wrong_answers;
    $("r-skipped").textContent = skipped;
    const mins = r.time_taken_seconds ? App.formatSeconds(r.time_taken_seconds) : "–";
    $("r-time").textContent = mins;
    $("btn-retry").href = "test.html?chapterId=" + r.chapter_id;

    $("review-list").innerHTML = r.review.map((item, i) => {
      const opts = ["A", "B", "C", "D"].map(letter => {
        const text = item["option_" + letter.toLowerCase()];
        const isCorrect = letter === item.correct_option;
        const isSelected = letter === item.selected_option;
        const cls = isCorrect ? "correct" : isSelected ? "wrong" : "";
        const mark = isCorrect ? "✓ Correct answer" : isSelected ? "✗ Your answer" : "";
        return `<div class="review-opt ${cls}">
                  <span class="opt-letter">${letter}</span>
                  <span>${App.escapeHtml(text)}</span>
                  ${mark ? `<span class="opt-mark">${mark}</span>` : ""}
                </div>`;
      }).join("");
      return `<div class="card review-item">
                <h3>Q${i + 1}. ${App.escapeHtml(item.question_text)}</h3>
                <div class="review-options">${opts}</div>
                ${item.explanation ? `<div class="explanation"><strong>Explanation</strong>${App.escapeHtml(item.explanation)}</div>` : ""}
              </div>`;
    }).join("");
  } catch (err) {
    if (err.status === 401) { App.logout(); return; }
    $("result-loading").textContent = err.message;
  }
});
