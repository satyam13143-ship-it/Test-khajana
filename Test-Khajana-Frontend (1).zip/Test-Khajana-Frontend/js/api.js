/* ============================================================
   TEST KHAJANA — API client
   ------------------------------------------------------------
   👉 SET THIS to your deployed backend URL after you deploy it:
      e.g. "https://test-khajana-api.onrender.com"
   For local development use "http://localhost:5000".
   No database credentials or AI keys ever live in the frontend.
   ============================================================ */
const API_BASE_URL = "https://YOUR-BACKEND-URL.com";

/** Central fetch wrapper: attaches JWT, parses JSON, normalises errors. */
async function apiFetch(path, { method = "GET", body } = {}) {
  const token = localStorage.getItem("tk_token");
  const headers = { "Content-Type": "application/json" };
  if (token) headers["Authorization"] = "Bearer " + token;

  let res;
  try {
    res = await fetch(API_BASE_URL + path, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch (e) {
    throw new Error("Cannot reach the server. Check your internet connection and that the backend is deployed.");
  }

  let data = null;
  try { data = await res.json(); } catch (_) { /* non-JSON response */ }

  if (!res.ok) {
    const message = (data && data.error) ? data.error : "Request failed (" + res.status + ")";
    const err = new Error(message);
    err.status = res.status;
    throw err;
  }
  return data;
}

/** Namespace of typed helpers used across pages. */
const Api = {
  // --- auth ---
  register: (payload) => apiFetch("/api/auth/register", { method: "POST", body: payload }),
  login:    (payload) => apiFetch("/api/auth/login",    { method: "POST", body: payload }),

  // --- catalogue ---
  getClasses:  ()        => apiFetch("/api/classes"),
  getSubjects: (classId) => apiFetch("/api/classes/" + classId + "/subjects"),
  getChapters: (subjectId) => apiFetch("/api/subjects/" + subjectId + "/chapters"),

  // --- tests ---
  startTest: (chapterId) => apiFetch("/api/tests/start", { method: "POST", body: { chapterId } }),
  submitTest: (attemptId, answers) =>
    apiFetch("/api/tests/submit", { method: "POST", body: { attemptId, answers } }),

  // --- results & history ---
  getResult: (attemptId) => apiFetch("/api/results/" + attemptId),
  getHistory: (userId)   => apiFetch("/api/users/" + userId + "/history"),

  // --- AI doubt assistant ---
  askDoubt: (message, conversationId) =>
    apiFetch("/api/ai/doubt", { method: "POST", body: { message, conversationId } }),
};
