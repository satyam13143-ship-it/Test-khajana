/* ============================================================
   TEST KHAJANA — shared app shell (header, bottom nav, helpers)
   ============================================================ */
const App = {
  tokenKey: "tk_token",
  userKey: "tk_user",

  user() {
    try { return JSON.parse(localStorage.getItem(this.userKey)); } catch (_) { return null; }
  },
  isLoggedIn() { return !!localStorage.getItem(this.tokenKey); },

  /** Redirect to login if not authenticated. Returns false if redirected. */
  requireAuth() {
    if (!this.isLoggedIn()) {
      window.location.replace("login.html");
      return false;
    }
    return true;
  },

  logout() {
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.userKey);
    window.location.replace("index.html");
  },

  initLogout() {
    const btn = document.getElementById("logout-btn");
    if (btn) btn.addEventListener("click", () => this.logout());
  },

  /* ---------- chrome ---------- */
  renderChrome() {
    const page = (document.body.dataset.page || "").trim();
    const user = this.user();
    const links = [
      ["index.html", "Home"],
      ["classes.html", "Classes"],
      ["history.html", "History"],
      ["ai-doubt.html", "AI Doubt"],
    ];
    const linkHtml = links
      .map(([href, label]) => `<a href="${href}" class="${page === href ? "active" : ""}">${label}</a>`)
      .join("");

    const header = document.getElementById("app-header");
    if (header) {
      header.innerHTML = `
        <div class="nav-inner">
          <a class="brand" href="index.html">
            <span class="brand-mark">TK</span>
            <span class="brand-name">Test <span class="gold">Khajana</span></span>
          </a>
          <nav class="nav-links">${linkHtml}</nav>
          <div class="nav-cta">
            ${user
              ? `<a class="btn btn-primary btn-sm" href="dashboard.html">Dashboard</a>`
              : `<a class="btn btn-ghost btn-sm" href="login.html">Log in</a>
                 <a class="btn btn-primary btn-sm" href="register.html">Sign up</a>`}
          </div>
        </div>`;
    }

    const nav = document.getElementById("bottom-nav");
    if (nav) {
      const items = [
        ["index.html", "🏠", "Home"],
        ["classes.html", "📚", "Classes"],
        ["__pass__", "⚡", "Pass"],
        ["history.html", "📜", "History"],
        ["profile.html", "👤", "Profile"],
      ];
      nav.innerHTML = items
        .map(([href, icon, label]) => {
          if (href === "__pass__")
            return `<a class="bn-item bn-pass" href="dashboard.html" title="Test Khajana Pass"><span class="bn-icon">⚡</span><span>Pass</span></a>`;
          const active = page === href ? " active" : "";
          return `<a class="bn-item${active}" href="${href}"><span class="bn-icon">${icon}</span><span>${label}</span></a>`;
        })
        .join("");
    }
  },

  /* ---------- helpers ---------- */
  escapeHtml(str) {
    const map = { "&": "amp", "<": "lt", ">": "gt", '"': "quot", "'": "#39" };
    return String(str == null ? "" : str).replace(/[&<>"']/g, (ch) => "&" + map[ch] + ";");
  },
  qs(name) { return new URLSearchParams(window.location.search).get(name); },
  formatDate(iso) {
    if (!iso) return "";
    const d = new Date(iso);
    return d.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) +
      ", " + d.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
  },
  formatSeconds(total) {
    const m = Math.floor(total / 60), s = total % 60;
    return m + "m " + String(s).padStart(2, "0") + "s";
  },
  toast(message, type = "") {
    const root = document.getElementById("toast-root");
    if (!root) return;
    const el = document.createElement("div");
    el.className = "toast " + type;
    el.textContent = message;
    root.appendChild(el);
    setTimeout(() => el.remove(), 3800);
  },
  initials(name) {
    return String(name || "?").trim().split(/\s+/).slice(0, 2)
      .map(w => w[0] ? w[0].toUpperCase() : "").join("") || "?";
  },
};

document.addEventListener("DOMContentLoaded", () => App.renderChrome());
