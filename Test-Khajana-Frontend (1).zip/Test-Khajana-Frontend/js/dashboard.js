/* dashboard.html — greeting, stats, recent attempts */
document.addEventListener("DOMContentLoaded", async () => {
  if (!App.requireAuth()) return;
  App.initLogout();

  const user = App.user() || {};
  document.getElementById("dash-hello").textContent = "Hello, " + (user.name || "student") + "! 👋";

  try {
    const history = await Api.getHistory(user.user_id || user.id);
    const tests = history.length;
    const avg = tests ? Math.round(history.reduce((s, h) => s + Number(h.score), 0) / tests) : 0;
    const best = tests ? Math.max(...history.map(h => Math.round(Number(h.score)))) : 0;
    document.getElementById("stat-tests").textContent = tests;
    document.getElementById("stat-avg").textContent = tests ? avg + "%" : "–";
    document.getElementById("stat-best").textContent = tests ? best + "%" : "–";

    const box = document.getElementById("dash-recent");
    if (!tests) {
      box.innerHTML = `<div class="empty-state card">No attempts yet — take your first test!</div>`;
    } else {
      box.innerHTML = history.slice(0, 5).map(h => `
        <a class="card row-card" href="result.html?attemptId=${h.attempt_id}">
          <div class="row-main">
            <h3>${App.escapeHtml(h.chapter_name)}</h3>
            <p class="row-sub">${App.escapeHtml(h.subject_name)} · ${App.formatDate(h.submitted_at || h.started_at)}</p>
          </div>
          <div class="row-right"><span class="pill ${h.score >= 60 ? "pill-green" : "pill-red"}">${Math.round(h.score)}%</span></div>
        </a>`).join("");
    }
  } catch (err) {
    if (err.status === 401) { App.logout(); return; }
    App.toast(err.message, "error");
  }
});
