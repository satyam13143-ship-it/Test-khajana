/* Login + register forms (login.html / register.html) */
document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("login-form");
  const registerForm = document.getElementById("register-form");

  function showError(id, msg) {
    const el = document.getElementById(id);
    el.textContent = msg;
    el.hidden = false;
  }
  function setBusy(btn, busy, label) {
    btn.disabled = busy;
    btn.textContent = busy ? "Please wait…" : label;
  }

  if (loginForm) {
    if (App.isLoggedIn()) { window.location.replace("dashboard.html"); return; }
    loginForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      document.getElementById("login-error").hidden = true;
      const btn = document.getElementById("login-submit");
      setBusy(btn, true, "Log In");
      try {
        const data = await Api.login({
          email: document.getElementById("login-email").value.trim(),
          password: document.getElementById("login-password").value,
        });
        localStorage.setItem("tk_token", data.token);
        localStorage.setItem("tk_user", JSON.stringify(data.user));
        window.location.replace("dashboard.html");
      } catch (err) {
        showError("login-error", err.message);
        setBusy(btn, false, "Log In");
      }
    });
  }

  if (registerForm) {
    if (App.isLoggedIn()) { window.location.replace("dashboard.html"); return; }
    registerForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      document.getElementById("register-error").hidden = true;
      const password = document.getElementById("reg-password").value;
      const confirm = document.getElementById("reg-confirm").value;
      if (password !== confirm) { showError("register-error", "Passwords do not match."); return; }
      const btn = document.getElementById("register-submit");
      setBusy(btn, true, "Create Account");
      try {
        const data = await Api.register({
          name: document.getElementById("reg-name").value.trim(),
          email: document.getElementById("reg-email").value.trim(),
          password,
        });
        localStorage.setItem("tk_token", data.token);
        localStorage.setItem("tk_user", JSON.stringify(data.user));
        window.location.replace("dashboard.html");
      } catch (err) {
        showError("register-error", err.message);
        setBusy(btn, false, "Create Account");
      }
    });
  }
});
