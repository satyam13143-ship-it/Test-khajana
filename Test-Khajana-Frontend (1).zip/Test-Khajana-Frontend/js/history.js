/* history.html — user's attempt list */
document.addEventListener("DOMContentLoaded", async () => {
  if (!App.requireAuth()) return;
  App.initLogout();

  const user = App.user() || {};
  const box = document.getElementById("history-list");

  try {
    const history = await Api.getHistory(user.user_id || user.id);
    if (!history.length) {
      box.innerHTML = `<div class="empty-state card">No tests yet. <a href="classes.html">Take your first test →</a></div>`;
      return;
    }
    box.innerHTML = history.map(h => `
      <a class="card row-card" href="result.html?attemptId=${h.attempt_id}">
        <div class="row-main">
          <h3>${App.escapeHtml(h.chapter_name)}</h3>
          <p class="row-sub">${App.escapeHtml(h.subject_name)} · ${App.escapeHtml(h.class_display_name)} · ${App.formatDate(h.submitted_at || h.started_at)}</p>
        </div>
        <div class="row-right">
          <span class="pill ${h.score >= 60 ? "pill-green" : "pill-red"}">${Math.round(h.score)}%</span>
          <p class="row-sub">${h.correct_answers}/${h.total_questions} correct</p>
        </div>
      </a>`).join("");
  } catch (err) {
    if (err.status === 401) { App.logout(); return; }
    box.innerHTML = `<div class="empty-state card">${App.escapeHtml(err.message)}</div>`;
  }
});
