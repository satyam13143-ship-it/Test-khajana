/* profile.html — fill user card */
document.addEventListener("DOMContentLoaded", () => {
  if (!App.requireAuth()) return;
  const user = App.user() || {};
  document.getElementById("avatar").textContent = App.initials(user.name);
  document.getElementById("profile-name").textContent = user.name || "Student";
  document.getElementById("profile-email").textContent = user.email || "";
  document.getElementById("profile-since").textContent =
    user.created_at ? "Member since " + App.formatDate(user.created_at) : "";
});
