/* ai-doubt.html — chat UI for the AI Doubt Assistant (backend proxies the AI key) */
document.addEventListener("DOMContentLoaded", () => {
  if (!App.requireAuth()) return;

  const form = document.getElementById("doubt-form");
  const input = document.getElementById("doubt-input");
  const windowEl = document.getElementById("chat-window");
  const sendBtn = document.getElementById("doubt-send");
  const clearBtn = document.getElementById("doubt-clear");
  let conversationId = Number(sessionStorage.getItem("tk_conversation")) || null;

  function addMsg(role, text, typing = false) {
    const wrap = document.createElement("div");
    wrap.className = "chat-msg " + role;
    const bubble = document.createElement("div");
    bubble.className = "bubble" + (typing ? " typing" : "");
    bubble.textContent = text;
    wrap.appendChild(bubble);
    windowEl.appendChild(wrap);
    windowEl.scrollTop = windowEl.scrollHeight;
    return bubble;
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const message = input.value.trim();
    if (!message) return;
    input.value = "";
    addMsg("user", message);
    const typingBubble = addMsg("bot", "Thinking…", true);
    sendBtn.disabled = true;

    try {
      const res = await Api.askDoubt(message, conversationId || undefined);
      conversationId = res.conversationId;
      sessionStorage.setItem("tk_conversation", conversationId);
      typingBubble.textContent = res.reply;
    } catch (err) {
      if (err.status === 401) { App.logout(); return; }
      typingBubble.textContent = "⚠ " + err.message;
    } finally {
      typingBubble.classList.remove("typing");
      windowEl.scrollTop = windowEl.scrollHeight;
      sendBtn.disabled = false;
      input.focus();
    }
  });

  clearBtn.addEventListener("click", () => {
    conversationId = null;
    sessionStorage.removeItem("tk_conversation");
    windowEl.innerHTML = `<div class="chat-msg bot"><div class="bubble">New chat started. Ask me anything!</div></div>`;
  });
});
