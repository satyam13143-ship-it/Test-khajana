/* test.html — objective test player: timer, navigation, palette, submit */
document.addEventListener("DOMContentLoaded", async () => {
  if (!App.requireAuth()) return;

  const chapterId = App.qs("chapterId");
  if (!chapterId) { window.location.replace("classes.html"); return; }

  const state = {
    attemptId: null,
    questions: [],
    answers: {},      // questionId -> 'A'|'B'|'C'|'D'
    current: 0,
    remaining: 0,
    timerId: null,
    submitting: false,
  };

  const $ = (id) => document.getElementById(id);

  try {
    const data = await Api.startTest(chapterId);
    if (!data.questions.length) {
      $("test-loading").textContent = "No questions available for this chapter yet.";
      return;
    }
    state.attemptId = data.attemptId;
    state.questions = data.questions;
    state.remaining = data.durationMinutes * 60;

    $("test-loading").hidden = true;
    $("test-container").hidden = false;
    $("test-chapter").textContent = data.chapterName;
    $("test-meta-count").textContent = data.questions.length;
    const difficulties = data.questions.map(q => q.difficulty);
    $("test-meta-diff").textContent =
      [...new Set(difficulties)].length === 1 ? difficulties[0] + " level" : "mixed level";

    renderQuestion();
    startTimer();
  } catch (err) {
    if (err.status === 401) { App.logout(); return; }
    $("test-loading").textContent = err.message;
  }

  /* ---------- rendering ---------- */
  function renderQuestion() {
    const q = state.questions[state.current];
    $("q-num").textContent = "Question " + (state.current + 1) + " of " + state.questions.length;
    $("q-diff").textContent = q.difficulty || "";
    $("q-text").textContent = q.question_text;
    $("options").innerHTML = ["A", "B", "C", "D"].map(letter => `
      <div class="option ${state.answers[q.question_id] === letter ? "selected" : ""}" data-letter="${letter}" role="button" tabindex="0">
        <span class="opt-letter">${letter}</span>
        <span>${App.escapeHtml(q["option_" + letter.toLowerCase()])}</span>
      </div>`).join("");

    document.querySelectorAll(".option").forEach(el => {
      el.addEventListener("click", () => select(q.question_id, el.dataset.letter));
    });

    $("btn-prev").disabled = state.current === 0;
    $("btn-next").textContent = state.current === state.questions.length - 1 ? "Review" : "Next";
    renderPalette();
  }

  function select(questionId, letter) {
    if (state.answers[questionId] === letter) delete state.answers[questionId];
    else state.answers[questionId] = letter;
    renderQuestion();
  }

  function renderPalette() {
    $("palette").innerHTML = state.questions.map((q, i) => {
      const cls = [
        "palette-btn",
        state.answers[q.question_id] ? "answered" : "",
        i === state.current ? "current" : "",
      ].join(" ");
      return `<button class="${cls}" data-index="${i}">${i + 1}</button>`;
    }).join("");
    $("palette").querySelectorAll(".palette-btn").forEach(btn => {
      btn.addEventListener("click", () => { state.current = Number(btn.dataset.index); renderQuestion(); });
    });
    const answered = Object.keys(state.answers).length;
    $("answered-count").textContent = answered + " of " + state.questions.length + " answered";
  }

  /* ---------- timer ---------- */
  function startTimer() {
    updateTimer();
    state.timerId = setInterval(() => {
      state.remaining--;
      updateTimer();
      if (state.remaining <= 0) {
        clearInterval(state.timerId);
        App.toast("Time's up! Submitting your test…");
        submit();
      }
    }, 1000);
  }
  function updateTimer() {
    const m = Math.floor(state.remaining / 60), s = state.remaining % 60;
    const el = $("test-timer");
    el.textContent = String(m).padStart(2, "0") + ":" + String(s).padStart(2, "0");
    el.classList.toggle("warning", state.remaining <= 60);
  }

  /* ---------- navigation ---------- */
  $("btn-prev").addEventListener("click", () => {
    if (state.current > 0) { state.current--; renderQuestion(); }
  });
  $("btn-next").addEventListener("click", () => {
    if (state.current < state.questions.length - 1) { state.current++; renderQuestion(); }
  });

  /* ---------- submit ---------- */
  $("btn-submit").addEventListener("click", () => {
    const unanswered = state.questions.length - Object.keys(state.answers).length;
    $("submit-summary").textContent =
      unanswered > 0
        ? `You still have ${unanswered} unanswered question${unanswered > 1 ? "s" : ""}. Unanswered questions are marked incorrect.`
        : "All questions answered. Ready to see your score?";
    $("submit-modal").hidden = false;
  });
  $("submit-cancel").addEventListener("click", () => { $("submit-modal").hidden = true; });

  async function submit() {
    if (state.submitting) return;
    state.submitting = true;
    clearInterval(state.timerId);
    $("submit-modal").hidden = true;
    $("btn-submit").disabled = true;
    try {
      const answers = state.questions
        .filter(q => state.answers[q.question_id])
        .map(q => ({ questionId: q.question_id, selectedOption: state.answers[q.question_id] }));
      const res = await Api.submitTest(state.attemptId, answers);
      window.location.replace("result.html?attemptId=" + res.attemptId);
    } catch (err) {
      if (err.status === 401) { App.logout(); return; }
      App.toast(err.message, "error");
      state.submitting = false;
      $("btn-submit").disabled = false;
      startTimer();
    }
  }
  $("submit-confirm").addEventListener("click", submit);

  /* warn before leaving an in-progress test */
  window.addEventListener("beforeunload", (e) => {
    if (state.attemptId && !state.submitting) { e.preventDefault(); e.returnValue = ""; }
  });
});
