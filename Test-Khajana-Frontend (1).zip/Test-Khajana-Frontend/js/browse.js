/* classes.html / subjects.html / chapters.html — catalogue browsing */
document.addEventListener("DOMContentLoaded", async () => {
  const path = window.location.pathname.split("/").pop() || "index.html";

  if (path === "classes.html") {
    try {
      const classes = await Api.getClasses();
      const box = document.getElementById("classes-list");
      if (!classes.length) {
        box.innerHTML = `<div class="empty-state card">No classes available yet. Please check back soon.</div>`;
        return;
      }
      box.innerHTML = classes.map(c => `
        <a class="class-card card" href="subjects.html?classId=${c.class_id}">
          <span class="class-num">${c.class_number}</span>
          <span class="class-label">${App.escapeHtml(c.display_name)}</span>
          <span class="row-sub">${c.subject_count} subjects</span>
        </a>`).join("");
    } catch (err) { failPage("classes-list", err); }
  }

  if (path === "subjects.html") {
    const classId = App.qs("classId");
    if (!classId) { window.location.replace("classes.html"); return; }
    try {
      const subjectsWithMeta = await Api.getSubjects(classId);
      document.getElementById("subjects-title").textContent = (subjectsWithMeta[0] && subjectsWithMeta[0].class_display_name) || "Subjects";
      const box = document.getElementById("subjects-list");
      if (!subjectsWithMeta.length) {
        box.innerHTML = `<div class="empty-state card">No subjects added for this class yet.</div>`;
        return;
      }
      box.innerHTML = subjectsWithMeta.map(s => `
        <a class="card row-card" href="chapters.html?subjectId=${s.subject_id}">
          <div class="row-main">
            <h3>${App.escapeHtml(s.name)}</h3>
            <p class="row-sub">${s.chapter_count} chapters</p>
          </div>
          <div class="row-right"><span class="chevron">&rsaquo;</span></div>
        </a>`).join("");
    } catch (err) { failPage("subjects-list", err); }
  }

  if (path === "chapters.html") {
    const subjectId = App.qs("subjectId");
    if (!subjectId) { window.location.replace("classes.html"); return; }
    try {
      const chapters = await Api.getChapters(subjectId);
      document.getElementById("chapters-title").textContent =
        (chapters[0] && chapters[0].subject_name) || "Chapters";
      const box = document.getElementById("chapters-list");
      if (!chapters.length) {
        box.innerHTML = `<div class="empty-state card">No chapters added for this subject yet.</div>`;
        return;
      }
      box.innerHTML = chapters.map(ch => `
        <a class="card row-card" href="test.html?chapterId=${ch.chapter_id}">
          <div class="row-main">
            <h3>Ch ${ch.chapter_number}. ${App.escapeHtml(ch.name)}</h3>
            <p class="row-sub">${ch.question_count} questions · ~${Math.max(10, Math.ceil(ch.question_count * 0.75))} min</p>
          </div>
          <div class="row-right">
            <span class="pill ${ch.question_count ? "pill-blue" : "pill-gold"}">${ch.question_count ? "Start Test" : "Coming soon"}</span>
          </div>
        </a>`).join("");
    } catch (err) { failPage("chapters-list", err); }
  }
});

function failPage(id, err) {
  const box = document.getElementById(id);
  if (box) box.innerHTML = `<div class="empty-state card">${App.escapeHtml(err.message)}</div>`;
}
