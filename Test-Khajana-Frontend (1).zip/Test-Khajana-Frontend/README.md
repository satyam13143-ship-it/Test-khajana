# Test Khajana — Frontend

A premium, mobile-first education & objective-test UI for **Class 9–12** students.
Pure **HTML5 + CSS3 + Vanilla JavaScript** — no Node.js, no build step. Deployable directly on **GitHub Pages**.

## Pages

| File | Purpose |
|---|---|
| `index.html` | Home — hero, pass card, AI doubt card, class grid, recent tests |
| `login.html` / `register.html` | Auth screens |
| `dashboard.html` | Stats (tests taken, average, best) + recent attempts |
| `classes.html` | Class 9–12 selection |
| `subjects.html` | Subjects of the chosen class |
| `chapters.html` | Chapters of a subject (question counts) |
| `test.html` | Test player — timer, question palette, next/prev, submit modal, auto-submit on timeout |
| `result.html` | Score ring, stats, full answer review with explanations |
| `history.html` | All past attempts |
| `ai-doubt.html` | AI Doubt Assistant chat |
| `profile.html` | Profile + logout |

## Configuration (IMPORTANT)

Open `js/api.js` and set:

```js
const API_BASE_URL = "https://YOUR-BACKEND-URL.com";
```

- After you deploy the backend (Part 2), paste its URL here and re-push.
- For local development use `http://localhost:5000`.
- **No database credentials and no AI keys ever go in the frontend** — every
  request goes through the backend REST API, and the AI is proxied by the backend.

## Run locally

Just open `index.html` in a browser, or serve the folder:

```bash
cd Test-Khajana-Frontend
python3 -m http.server 8000
# open http://localhost:8000
```

## Deploy on GitHub Pages

1. Create a repository (e.g. `test-khajana-frontend`) and push this folder's contents to it:
   ```bash
   git init
   git add .
   git commit -m "Test Khajana frontend"
   git branch -M main
   git remote add origin https://github.com/<your-username>/test-khajana-frontend.git
   git push -u origin main
   ```
2. On GitHub: **Settings → Pages → Source: Deploy from a branch → Branch: `main` / `/ (root)` → Save**.
3. Your site will be live at `https://<your-username>.github.io/test-khajana-frontend/`.
4. Set `API_BASE_URL` in `js/api.js` to your backend URL (e.g. a Render/Railway URL) and push again.

## Structure

```
Test-Khajana-Frontend/
├── index.html, login.html, register.html, dashboard.html,
│   classes.html, subjects.html, chapters.html, test.html,
│   result.html, history.html, ai-doubt.html, profile.html
├── css/style.css        # design system (blue primary, gold accents)
├── js/
│   ├── api.js           # API_BASE_URL + fetch wrapper  ← configure here
│   ├── app.js           # header/bottom-nav shell, helpers, auth guard
│   ├── auth.js          # login/register flows
│   ├── home.js / dashboard.js / browse.js
│   ├── tests.js         # test player
│   ├── result.js        # score + review
│   ├── history.js / ai.js / profile.js
└── assets/logo/         # logo + favicon
```
